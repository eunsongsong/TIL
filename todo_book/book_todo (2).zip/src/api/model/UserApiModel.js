class UserApiModel{
    name;
    email;
    picture;

    constructor(name, email, picture){
        this.name = name;
        this.email = email;
        this.picture = picture;
    }
}
export default UserApiModel;